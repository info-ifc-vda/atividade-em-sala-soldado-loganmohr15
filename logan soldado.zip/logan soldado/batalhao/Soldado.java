
package batalhao;

public class Soldado {
    private String nome;
    private int posicao;
    private static int totalSoldados = 0;
    private static final int DISTANCIA_PADRAO = 5;
    private static final String ARMA_PADRAO = "fuzil";

    public Soldado(String nome) {
        this.nome = nome;
        this.posicao = 0;
        totalSoldados++;
    }

    public void movimentar() {
        this.movimentar(DISTANCIA_PADRAO);
    }

    public void movimentar(int distancia) {
        this.posicao += distancia;
        System.out.println(this.nome + " se moveu para a posição " + this.posicao);
    }

    public void atacar() {
        this.atacar(ARMA_PADRAO);
    }

    public void atacar(String arma) {
        if (totalSoldados >= 10) {
            System.out.println(this.nome + " está atacando com " + arma);
        } else {
            System.out.println(this.nome + " diz: ainda não, esperando o exército ficar maior.");
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPosicao() {
        return posicao;
    }

    public void setPosicao(int posicao) {
        this.posicao = posicao;
    }

    public static int getTotalSoldados() {
        return totalSoldados;
    }

    public static void main(String[] args) {
        Soldado soldado1 = new Soldado("Soldado 1");
        Soldado soldado2 = new Soldado("Soldado 2");
        // Adicione mais soldados conforme necessário para testar o comportamento

        soldado1.movimentar();
        soldado2.movimentar(10);

        soldado1.atacar();
        soldado2.atacar("baioneta");

        System.out.println("Total de soldados: " + Soldado.getTotalSoldados());
    }
}